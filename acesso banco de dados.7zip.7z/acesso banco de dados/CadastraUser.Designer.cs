﻿namespace acesso_banco_de_dados
{
    partial class CadastraUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeUsuario = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.lblRepeteSenha = new System.Windows.Forms.Label();
            this.txtCadastraNome = new System.Windows.Forms.TextBox();
            this.txtCadastraSenha = new System.Windows.Forms.TextBox();
            this.txtConfirmaSenha = new System.Windows.Forms.TextBox();
            this.btnCadastraUser = new System.Windows.Forms.Button();
            this.btnExibeOcultarSenha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNomeUsuario
            // 
            this.lblNomeUsuario.AutoSize = true;
            this.lblNomeUsuario.Location = new System.Drawing.Point(42, 23);
            this.lblNomeUsuario.Name = "lblNomeUsuario";
            this.lblNomeUsuario.Size = new System.Drawing.Size(173, 13);
            this.lblNomeUsuario.TabIndex = 0;
            this.lblNomeUsuario.Text = "Digite o nome de usuário desejado:";
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Location = new System.Drawing.Point(42, 86);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(124, 13);
            this.lblSenha.TabIndex = 0;
            this.lblSenha.Text = "Digite a senha desejada:";
            // 
            // lblRepeteSenha
            // 
            this.lblRepeteSenha.AutoSize = true;
            this.lblRepeteSenha.Location = new System.Drawing.Point(42, 148);
            this.lblRepeteSenha.Name = "lblRepeteSenha";
            this.lblRepeteSenha.Size = new System.Drawing.Size(152, 13);
            this.lblRepeteSenha.TabIndex = 0;
            this.lblRepeteSenha.Text = "Repita a senha para confirmar:";
            // 
            // txtCadastraNome
            // 
            this.txtCadastraNome.Location = new System.Drawing.Point(45, 50);
            this.txtCadastraNome.Name = "txtCadastraNome";
            this.txtCadastraNome.Size = new System.Drawing.Size(170, 20);
            this.txtCadastraNome.TabIndex = 1;
            // 
            // txtCadastraSenha
            // 
            this.txtCadastraSenha.Location = new System.Drawing.Point(45, 114);
            this.txtCadastraSenha.Name = "txtCadastraSenha";
            this.txtCadastraSenha.Size = new System.Drawing.Size(170, 20);
            this.txtCadastraSenha.TabIndex = 1;
            // 
            // txtConfirmaSenha
            // 
            this.txtConfirmaSenha.Location = new System.Drawing.Point(45, 179);
            this.txtConfirmaSenha.Name = "txtConfirmaSenha";
            this.txtConfirmaSenha.Size = new System.Drawing.Size(170, 20);
            this.txtConfirmaSenha.TabIndex = 1;
            // 
            // btnCadastraUser
            // 
            this.btnCadastraUser.Location = new System.Drawing.Point(76, 234);
            this.btnCadastraUser.Name = "btnCadastraUser";
            this.btnCadastraUser.Size = new System.Drawing.Size(109, 52);
            this.btnCadastraUser.TabIndex = 2;
            this.btnCadastraUser.Text = "Cadastrar Usuário";
            this.btnCadastraUser.UseVisualStyleBackColor = true;
            // 
            // btnExibeOcultarSenha
            // 
            this.btnExibeOcultarSenha.Location = new System.Drawing.Point(271, 105);
            this.btnExibeOcultarSenha.Name = "btnExibeOcultarSenha";
            this.btnExibeOcultarSenha.Size = new System.Drawing.Size(123, 37);
            this.btnExibeOcultarSenha.TabIndex = 2;
            this.btnExibeOcultarSenha.Text = "Exibir Senha\r\n";
            this.btnExibeOcultarSenha.UseVisualStyleBackColor = true;
            // 
            // CadastraUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExibeOcultarSenha);
            this.Controls.Add(this.btnCadastraUser);
            this.Controls.Add(this.txtConfirmaSenha);
            this.Controls.Add(this.txtCadastraSenha);
            this.Controls.Add(this.txtCadastraNome);
            this.Controls.Add(this.lblRepeteSenha);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.lblNomeUsuario);
            this.Name = "CadastraUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Novo Usuário";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeUsuario;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.Label lblRepeteSenha;
        private System.Windows.Forms.TextBox txtCadastraNome;
        private System.Windows.Forms.TextBox txtCadastraSenha;
        private System.Windows.Forms.TextBox txtConfirmaSenha;
        private System.Windows.Forms.Button btnCadastraUser;
        private System.Windows.Forms.Button btnExibeOcultarSenha;
    }
}