﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace acesso_banco_de_dados
{
    public partial class Form1 : Form
    {
        public string consulta;
        public string sql;

        public Form1()
        {
            InitializeComponent();
        }

        private void lblPrecoLivro_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Carrega ComboBox com método da classe CarregaComboBox e Lista:
            consulta = "SELECT Nome_Livro FROM tbl_Livro";
            CarregaComboBox carregaLivro = new CarregaComboBox();

            //Criar objeto de lista para armazenar os dados dos livros:
            List<string> Livros = new List<string>();
            Livros.AddRange(carregaLivro.carregaComboBox(consulta, "Nome_Livro"));

            //Copia dados da lsita para o ComboBox:
            cmbLivros.Items.AddRange(Livros.ToArray());
        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            //Consulta a ser realizada:
            consulta = "SELECT L.Nome_Livro, L.Preco_Livro, L.Data_Pub,A.Nome_Autor FROM tbl_Livro AS L INNER JOIN tbl_autores AS A ON L.ID_Autor = A.ID_Autor WHERE ID_Livro = " + txtCodLivro.Text;
            //MessageBox.Show(consulta);"Aqui Eu fui Burro"
            //Instanciar classe que realiza a consulta:
            ConsultarLivro consultarLivro = new ConsultarLivro();

            //Passar a string SQL para o método fazerConsulta()
            consultarLivro.fazerConsulta(consulta);

            //Mostrar os resultados nas caixas de texto;
            txtNomeLivro.Text = Variaveis.CaixaTxtNomeLivro;
            txtNomeAutor.Text = Variaveis.CaixaTxtNomeAutor;
            txtPrecoLivro.Text = Variaveis.CaixaTxtPrecoLivro;
            txtDataPub.Text = Variaveis.CaixaTxtDataPub.ToString("dd/MM/yyyy");
        }

        private void cmbLivros_SelectedIndexChanged(object sender, EventArgs e)
        {
            consulta = "SELECT L.Nome_Livro, L.Preco_Livro, L.Data_Pub, A.Nome_Autor FROM tbl_Livro AS L INNER JOIN tbl_autores AS A ON L.ID_Autor = A.ID_Autor WHERE L.Nome_Livro = '" + cmbLivros.SelectedItem.ToString() + "'";
            // Passa a string SQL para o método fazerConsulta:
            ConsultarLivro consultarLivro = new ConsultarLivro();
            consultarLivro.fazerConsulta(consulta);
            txtNomeLivro.Text = Variaveis.CaixaTxtNomeLivro;
            txtNomeAutor.Text = Variaveis.CaixaTxtNomeAutor;
            txtPrecoLivro.Text = Variaveis.CaixaTxtPrecoLivro;
            txtDataPub.Text = Variaveis.CaixaTxtDataPub.ToString("dd/MM/yyyy");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //Para reiniciar uma aplicação, use Application.Restart();
        }
    }
}
