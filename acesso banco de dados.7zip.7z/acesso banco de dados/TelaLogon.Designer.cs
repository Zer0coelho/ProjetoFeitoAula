﻿namespace acesso_banco_de_dados
{
    partial class TelaLogon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLogonUser = new System.Windows.Forms.TextBox();
            this.txtLogonSenha = new System.Windows.Forms.TextBox();
            this.btnLogon = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(191, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Digite o nome do usuário para logon:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Digite a senha do usuário\r\n\r\n";
            // 
            // txtLogonUser
            // 
            this.txtLogonUser.Location = new System.Drawing.Point(194, 75);
            this.txtLogonUser.Name = "txtLogonUser";
            this.txtLogonUser.Size = new System.Drawing.Size(177, 20);
            this.txtLogonUser.TabIndex = 1;
            this.txtLogonUser.TextChanged += new System.EventHandler(this.txtLogonUser_TextChanged);
            // 
            // txtLogonSenha
            // 
            this.txtLogonSenha.Location = new System.Drawing.Point(194, 165);
            this.txtLogonSenha.Name = "txtLogonSenha";
            this.txtLogonSenha.Size = new System.Drawing.Size(177, 20);
            this.txtLogonSenha.TabIndex = 1;
            // 
            // btnLogon
            // 
            this.btnLogon.Location = new System.Drawing.Point(232, 211);
            this.btnLogon.Name = "btnLogon";
            this.btnLogon.Size = new System.Drawing.Size(106, 49);
            this.btnLogon.TabIndex = 2;
            this.btnLogon.Text = "Entrar";
            this.btnLogon.UseVisualStyleBackColor = true;
            // 
            // TelaLogon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 383);
            this.Controls.Add(this.btnLogon);
            this.Controls.Add(this.txtLogonSenha);
            this.Controls.Add(this.txtLogonUser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "TelaLogon";
            this.Text = "Efetuar logon no Sistema";
            this.Load += new System.EventHandler(this.TelaLogon_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLogonUser;
        private System.Windows.Forms.TextBox txtLogonSenha;
        private System.Windows.Forms.Button btnLogon;
    }
}