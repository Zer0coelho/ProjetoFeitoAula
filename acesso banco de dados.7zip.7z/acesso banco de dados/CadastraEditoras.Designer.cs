﻿namespace acesso_banco_de_dados
{
    partial class CadastraEditoras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCadastraEditora = new System.Windows.Forms.Label();
            this.lblNomeEditora = new System.Windows.Forms.Label();
            this.txtEditora = new System.Windows.Forms.TextBox();
            this.btnCadastraEditora = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCadastraEditora
            // 
            this.lblCadastraEditora.AutoSize = true;
            this.lblCadastraEditora.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastraEditora.Location = new System.Drawing.Point(12, 9);
            this.lblCadastraEditora.Name = "lblCadastraEditora";
            this.lblCadastraEditora.Size = new System.Drawing.Size(374, 19);
            this.lblCadastraEditora.TabIndex = 0;
            this.lblCadastraEditora.Text = "Digite abaixo o nome da Editora para Cadastrar:\r\n";
            // 
            // lblNomeEditora
            // 
            this.lblNomeEditora.AutoSize = true;
            this.lblNomeEditora.Location = new System.Drawing.Point(13, 78);
            this.lblNomeEditora.Name = "lblNomeEditora";
            this.lblNomeEditora.Size = new System.Drawing.Size(89, 13);
            this.lblNomeEditora.TabIndex = 1;
            this.lblNomeEditora.Text = "Nome da Editora:";
            // 
            // txtEditora
            // 
            this.txtEditora.Location = new System.Drawing.Point(108, 78);
            this.txtEditora.Name = "txtEditora";
            this.txtEditora.Size = new System.Drawing.Size(195, 20);
            this.txtEditora.TabIndex = 2;
            // 
            // btnCadastraEditora
            // 
            this.btnCadastraEditora.Location = new System.Drawing.Point(63, 141);
            this.btnCadastraEditora.Name = "btnCadastraEditora";
            this.btnCadastraEditora.Size = new System.Drawing.Size(105, 27);
            this.btnCadastraEditora.TabIndex = 3;
            this.btnCadastraEditora.Text = "Cadastrar Editora";
            this.btnCadastraEditora.UseVisualStyleBackColor = true;
            // 
            // CadastraEditoras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 450);
            this.Controls.Add(this.btnCadastraEditora);
            this.Controls.Add(this.txtEditora);
            this.Controls.Add(this.lblNomeEditora);
            this.Controls.Add(this.lblCadastraEditora);
            this.Name = "CadastraEditoras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Editoras";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCadastraEditora;
        private System.Windows.Forms.Label lblNomeEditora;
        private System.Windows.Forms.TextBox txtEditora;
        private System.Windows.Forms.Button btnCadastraEditora;
    }
}