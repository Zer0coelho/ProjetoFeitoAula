﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace acesso_banco_de_dados
{
    public partial class TelaLogon : Form
    {
        public TelaLogon()
        {
            InitializeComponent();
        }

        private void TelaLogon_Load(object sender, EventArgs e)
        {

        }

        private void txtLogonUser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
