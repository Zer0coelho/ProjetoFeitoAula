﻿namespace acesso_banco_de_dados
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbldigite = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtCodLivro = new System.Windows.Forms.TextBox();
            this.lblNomeLivro = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.lblPrecoLivro = new System.Windows.Forms.Label();
            this.lblDataPub = new System.Windows.Forms.Label();
            this.btnConsulta = new System.Windows.Forms.Button();
            this.txtNomeLivro = new System.Windows.Forms.TextBox();
            this.txtNomeAutor = new System.Windows.Forms.TextBox();
            this.txtPrecoLivro = new System.Windows.Forms.TextBox();
            this.txtDataPub = new System.Windows.Forms.TextBox();
            this.lblLivroDisp = new System.Windows.Forms.Label();
            this.cmbLivros = new System.Windows.Forms.ComboBox();
            this.lblEscolhaLivro = new System.Windows.Forms.Label();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoresToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosEmGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.preçoTotalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbldigite
            // 
            this.lbldigite.AutoSize = true;
            this.lbldigite.Location = new System.Drawing.Point(-3, 39);
            this.lbldigite.Name = "lbldigite";
            this.lbldigite.Size = new System.Drawing.Size(122, 13);
            this.lbldigite.TabIndex = 0;
            this.lbldigite.Text = "Digite o código do Livro:\r\n";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.cadastroToolStripMenuItem,
            this.consultasToolStripMenuItem,
            this.ajudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(845, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.autoresToolStripMenuItem,
            this.editoraToolStripMenuItem,
            this.livrosToolStripMenuItem,
            this.usuáriosToolStripMenuItem});
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            // 
            // consultasToolStripMenuItem
            // 
            this.consultasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.autoresToolStripMenuItem1,
            this.editorasToolStripMenuItem,
            this.livrosEmGridToolStripMenuItem,
            this.preçoTotalToolStripMenuItem});
            this.consultasToolStripMenuItem.Name = "consultasToolStripMenuItem";
            this.consultasToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.consultasToolStripMenuItem.Text = "Consultas";
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreToolStripMenuItem});
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.ajudaToolStripMenuItem.Text = "Ajuda";
            // 
            // txtCodLivro
            // 
            this.txtCodLivro.Location = new System.Drawing.Point(125, 36);
            this.txtCodLivro.Name = "txtCodLivro";
            this.txtCodLivro.Size = new System.Drawing.Size(100, 20);
            this.txtCodLivro.TabIndex = 2;
            // 
            // lblNomeLivro
            // 
            this.lblNomeLivro.AutoSize = true;
            this.lblNomeLivro.Location = new System.Drawing.Point(12, 187);
            this.lblNomeLivro.Name = "lblNomeLivro";
            this.lblNomeLivro.Size = new System.Drawing.Size(79, 13);
            this.lblNomeLivro.TabIndex = 0;
            this.lblNomeLivro.Text = "Nome do Livro:\r\n";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Location = new System.Drawing.Point(10, 237);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(81, 26);
            this.lblNomeAutor.TabIndex = 0;
            this.lblNomeAutor.Text = "Nome do Autor:\r\n\r\n";
            // 
            // lblPrecoLivro
            // 
            this.lblPrecoLivro.AutoSize = true;
            this.lblPrecoLivro.Location = new System.Drawing.Point(12, 298);
            this.lblPrecoLivro.Name = "lblPrecoLivro";
            this.lblPrecoLivro.Size = new System.Drawing.Size(79, 26);
            this.lblPrecoLivro.TabIndex = 0;
            this.lblPrecoLivro.Text = "Preço do Livro:\r\n\r\n";
            this.lblPrecoLivro.Click += new System.EventHandler(this.lblPrecoLivro_Click);
            // 
            // lblDataPub
            // 
            this.lblDataPub.AutoSize = true;
            this.lblDataPub.Location = new System.Drawing.Point(-3, 345);
            this.lblDataPub.Name = "lblDataPub";
            this.lblDataPub.Size = new System.Drawing.Size(104, 39);
            this.lblDataPub.TabIndex = 0;
            this.lblDataPub.Text = "Data de Publicação:\r\n\r\n\r\n";
            // 
            // btnConsulta
            // 
            this.btnConsulta.Location = new System.Drawing.Point(125, 85);
            this.btnConsulta.Name = "btnConsulta";
            this.btnConsulta.Size = new System.Drawing.Size(100, 43);
            this.btnConsulta.TabIndex = 3;
            this.btnConsulta.Text = "Consultar\r\n";
            this.btnConsulta.UseVisualStyleBackColor = true;
            this.btnConsulta.Click += new System.EventHandler(this.btnConsulta_Click);
            // 
            // txtNomeLivro
            // 
            this.txtNomeLivro.Location = new System.Drawing.Point(107, 187);
            this.txtNomeLivro.Name = "txtNomeLivro";
            this.txtNomeLivro.Size = new System.Drawing.Size(151, 20);
            this.txtNomeLivro.TabIndex = 4;
            // 
            // txtNomeAutor
            // 
            this.txtNomeAutor.Location = new System.Drawing.Point(107, 237);
            this.txtNomeAutor.Name = "txtNomeAutor";
            this.txtNomeAutor.Size = new System.Drawing.Size(151, 20);
            this.txtNomeAutor.TabIndex = 4;
            // 
            // txtPrecoLivro
            // 
            this.txtPrecoLivro.Location = new System.Drawing.Point(107, 298);
            this.txtPrecoLivro.Name = "txtPrecoLivro";
            this.txtPrecoLivro.Size = new System.Drawing.Size(151, 20);
            this.txtPrecoLivro.TabIndex = 4;
            // 
            // txtDataPub
            // 
            this.txtDataPub.Location = new System.Drawing.Point(107, 345);
            this.txtDataPub.Name = "txtDataPub";
            this.txtDataPub.Size = new System.Drawing.Size(151, 20);
            this.txtDataPub.TabIndex = 4;
            // 
            // lblLivroDisp
            // 
            this.lblLivroDisp.AutoSize = true;
            this.lblLivroDisp.Location = new System.Drawing.Point(424, 39);
            this.lblLivroDisp.Name = "lblLivroDisp";
            this.lblLivroDisp.Size = new System.Drawing.Size(92, 13);
            this.lblLivroDisp.TabIndex = 5;
            this.lblLivroDisp.Text = "Livro Disponíveis:\r\n";
            // 
            // cmbLivros
            // 
            this.cmbLivros.FormattingEnabled = true;
            this.cmbLivros.Location = new System.Drawing.Point(427, 55);
            this.cmbLivros.Name = "cmbLivros";
            this.cmbLivros.Size = new System.Drawing.Size(275, 21);
            this.cmbLivros.TabIndex = 6;
            this.cmbLivros.SelectedIndexChanged += new System.EventHandler(this.cmbLivros_SelectedIndexChanged);
            // 
            // lblEscolhaLivro
            // 
            this.lblEscolhaLivro.AutoSize = true;
            this.lblEscolhaLivro.Location = new System.Drawing.Point(424, 79);
            this.lblEscolhaLivro.Name = "lblEscolhaLivro";
            this.lblEscolhaLivro.Size = new System.Drawing.Size(245, 13);
            this.lblEscolhaLivro.TabIndex = 5;
            this.lblEscolhaLivro.Text = "Escolha um livro na caixa suspensa para consultar\r\n";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // autoresToolStripMenuItem
            // 
            this.autoresToolStripMenuItem.Name = "autoresToolStripMenuItem";
            this.autoresToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.autoresToolStripMenuItem.Text = "Autores";
            // 
            // editoraToolStripMenuItem
            // 
            this.editoraToolStripMenuItem.Name = "editoraToolStripMenuItem";
            this.editoraToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.editoraToolStripMenuItem.Text = "Editora";
            // 
            // livrosToolStripMenuItem
            // 
            this.livrosToolStripMenuItem.Name = "livrosToolStripMenuItem";
            this.livrosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.livrosToolStripMenuItem.Text = "Livros";
            // 
            // usuáriosToolStripMenuItem
            // 
            this.usuáriosToolStripMenuItem.Name = "usuáriosToolStripMenuItem";
            this.usuáriosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.usuáriosToolStripMenuItem.Text = "Usuários";
            // 
            // autoresToolStripMenuItem1
            // 
            this.autoresToolStripMenuItem1.Name = "autoresToolStripMenuItem1";
            this.autoresToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.autoresToolStripMenuItem1.Text = "Autores";
            // 
            // editorasToolStripMenuItem
            // 
            this.editorasToolStripMenuItem.Name = "editorasToolStripMenuItem";
            this.editorasToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.editorasToolStripMenuItem.Text = "Editoras";
            // 
            // livrosEmGridToolStripMenuItem
            // 
            this.livrosEmGridToolStripMenuItem.Name = "livrosEmGridToolStripMenuItem";
            this.livrosEmGridToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.livrosEmGridToolStripMenuItem.Text = "Livros em Grid";
            // 
            // preçoTotalToolStripMenuItem
            // 
            this.preçoTotalToolStripMenuItem.Name = "preçoTotalToolStripMenuItem";
            this.preçoTotalToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.preçoTotalToolStripMenuItem.Text = "Preço Total";
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sobreToolStripMenuItem.Text = "Sobre";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 518);
            this.Controls.Add(this.cmbLivros);
            this.Controls.Add(this.lblEscolhaLivro);
            this.Controls.Add(this.lblLivroDisp);
            this.Controls.Add(this.txtDataPub);
            this.Controls.Add(this.txtPrecoLivro);
            this.Controls.Add(this.txtNomeAutor);
            this.Controls.Add(this.txtNomeLivro);
            this.Controls.Add(this.btnConsulta);
            this.Controls.Add(this.txtCodLivro);
            this.Controls.Add(this.lblDataPub);
            this.Controls.Add(this.lblPrecoLivro);
            this.Controls.Add(this.lblNomeAutor);
            this.Controls.Add(this.lblNomeLivro);
            this.Controls.Add(this.lbldigite);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbldigite;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.TextBox txtCodLivro;
        private System.Windows.Forms.Label lblNomeLivro;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.Label lblPrecoLivro;
        private System.Windows.Forms.Label lblDataPub;
        private System.Windows.Forms.Button btnConsulta;
        private System.Windows.Forms.TextBox txtNomeLivro;
        private System.Windows.Forms.TextBox txtNomeAutor;
        private System.Windows.Forms.TextBox txtPrecoLivro;
        private System.Windows.Forms.TextBox txtDataPub;
        private System.Windows.Forms.Label lblLivroDisp;
        private System.Windows.Forms.ComboBox cmbLivros;
        private System.Windows.Forms.Label lblEscolhaLivro;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem livrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autoresToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editorasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem livrosEmGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem preçoTotalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
    }
}

