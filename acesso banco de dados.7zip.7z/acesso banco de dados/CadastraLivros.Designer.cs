﻿namespace acesso_banco_de_dados
{
    partial class CadastraLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCadastraLivro = new System.Windows.Forms.Label();
            this.lblNomeLivro = new System.Windows.Forms.Label();
            this.lblISBN = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.lblDataPub = new System.Windows.Forms.Label();
            this.lblPrecoLivro = new System.Windows.Forms.Label();
            this.lblNomeEditora = new System.Windows.Forms.Label();
            this.cmbIDAutor = new System.Windows.Forms.ComboBox();
            this.cmdIDEditora = new System.Windows.Forms.ComboBox();
            this.dtpDataPub = new System.Windows.Forms.DateTimePicker();
            this.txtNomeLivro = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.txtPrecoLivro = new System.Windows.Forms.TextBox();
            this.btnCadastraLivro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCadastraLivro
            // 
            this.lblCadastraLivro.AutoSize = true;
            this.lblCadastraLivro.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastraLivro.Location = new System.Drawing.Point(12, 9);
            this.lblCadastraLivro.Name = "lblCadastraLivro";
            this.lblCadastraLivro.Size = new System.Drawing.Size(416, 19);
            this.lblCadastraLivro.TabIndex = 0;
            this.lblCadastraLivro.Text = "Preencha os campos abaixo para cadastrar um Livro:\r\n";
            // 
            // lblNomeLivro
            // 
            this.lblNomeLivro.AutoSize = true;
            this.lblNomeLivro.Location = new System.Drawing.Point(13, 66);
            this.lblNomeLivro.Name = "lblNomeLivro";
            this.lblNomeLivro.Size = new System.Drawing.Size(79, 13);
            this.lblNomeLivro.TabIndex = 1;
            this.lblNomeLivro.Text = "Nome do Livro:";
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Location = new System.Drawing.Point(36, 104);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(35, 13);
            this.lblISBN.TabIndex = 2;
            this.lblISBN.Text = "ISBN:";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Location = new System.Drawing.Point(13, 141);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(81, 13);
            this.lblNomeAutor.TabIndex = 2;
            this.lblNomeAutor.Text = "Nome do Autor:";
            // 
            // lblDataPub
            // 
            this.lblDataPub.AutoSize = true;
            this.lblDataPub.Location = new System.Drawing.Point(13, 181);
            this.lblDataPub.Name = "lblDataPub";
            this.lblDataPub.Size = new System.Drawing.Size(104, 13);
            this.lblDataPub.TabIndex = 2;
            this.lblDataPub.Text = "Data da Publicação:";
            // 
            // lblPrecoLivro
            // 
            this.lblPrecoLivro.AutoSize = true;
            this.lblPrecoLivro.Location = new System.Drawing.Point(13, 222);
            this.lblPrecoLivro.Name = "lblPrecoLivro";
            this.lblPrecoLivro.Size = new System.Drawing.Size(79, 13);
            this.lblPrecoLivro.TabIndex = 2;
            this.lblPrecoLivro.Text = "Preço do Livro:";
            this.lblPrecoLivro.Click += new System.EventHandler(this.lblPrecoLivro_Click);
            // 
            // lblNomeEditora
            // 
            this.lblNomeEditora.AutoSize = true;
            this.lblNomeEditora.Location = new System.Drawing.Point(13, 265);
            this.lblNomeEditora.Name = "lblNomeEditora";
            this.lblNomeEditora.Size = new System.Drawing.Size(89, 13);
            this.lblNomeEditora.TabIndex = 2;
            this.lblNomeEditora.Text = "Nome da Editora:";
            this.lblNomeEditora.Click += new System.EventHandler(this.lblPrecoLivro_Click);
            // 
            // cmbIDAutor
            // 
            this.cmbIDAutor.FormattingEnabled = true;
            this.cmbIDAutor.Location = new System.Drawing.Point(109, 138);
            this.cmbIDAutor.Name = "cmbIDAutor";
            this.cmbIDAutor.Size = new System.Drawing.Size(121, 21);
            this.cmbIDAutor.TabIndex = 3;
            // 
            // cmdIDEditora
            // 
            this.cmdIDEditora.FormattingEnabled = true;
            this.cmdIDEditora.Location = new System.Drawing.Point(109, 265);
            this.cmdIDEditora.Name = "cmdIDEditora";
            this.cmdIDEditora.Size = new System.Drawing.Size(121, 21);
            this.cmdIDEditora.TabIndex = 3;
            // 
            // dtpDataPub
            // 
            this.dtpDataPub.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataPub.Location = new System.Drawing.Point(123, 181);
            this.dtpDataPub.Name = "dtpDataPub";
            this.dtpDataPub.Size = new System.Drawing.Size(107, 20);
            this.dtpDataPub.TabIndex = 4;
            // 
            // txtNomeLivro
            // 
            this.txtNomeLivro.Location = new System.Drawing.Point(98, 63);
            this.txtNomeLivro.Name = "txtNomeLivro";
            this.txtNomeLivro.Size = new System.Drawing.Size(142, 20);
            this.txtNomeLivro.TabIndex = 5;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(98, 101);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(142, 20);
            this.txtISBN.TabIndex = 5;
            // 
            // txtPrecoLivro
            // 
            this.txtPrecoLivro.Location = new System.Drawing.Point(98, 222);
            this.txtPrecoLivro.Name = "txtPrecoLivro";
            this.txtPrecoLivro.Size = new System.Drawing.Size(142, 20);
            this.txtPrecoLivro.TabIndex = 5;
            // 
            // btnCadastraLivro
            // 
            this.btnCadastraLivro.Location = new System.Drawing.Point(109, 326);
            this.btnCadastraLivro.Name = "btnCadastraLivro";
            this.btnCadastraLivro.Size = new System.Drawing.Size(101, 41);
            this.btnCadastraLivro.TabIndex = 6;
            this.btnCadastraLivro.Text = "Cadastrar Livro";
            this.btnCadastraLivro.UseVisualStyleBackColor = true;
            // 
            // CadastraLivros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCadastraLivro);
            this.Controls.Add(this.txtPrecoLivro);
            this.Controls.Add(this.txtISBN);
            this.Controls.Add(this.txtNomeLivro);
            this.Controls.Add(this.dtpDataPub);
            this.Controls.Add(this.cmdIDEditora);
            this.Controls.Add(this.cmbIDAutor);
            this.Controls.Add(this.lblNomeEditora);
            this.Controls.Add(this.lblPrecoLivro);
            this.Controls.Add(this.lblDataPub);
            this.Controls.Add(this.lblNomeAutor);
            this.Controls.Add(this.lblISBN);
            this.Controls.Add(this.lblNomeLivro);
            this.Controls.Add(this.lblCadastraLivro);
            this.Name = "CadastraLivros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Livros";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCadastraLivro;
        private System.Windows.Forms.Label lblNomeLivro;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.Label lblDataPub;
        private System.Windows.Forms.Label lblPrecoLivro;
        private System.Windows.Forms.Label lblNomeEditora;
        private System.Windows.Forms.ComboBox cmbIDAutor;
        private System.Windows.Forms.ComboBox cmdIDEditora;
        private System.Windows.Forms.DateTimePicker dtpDataPub;
        private System.Windows.Forms.TextBox txtNomeLivro;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.TextBox txtPrecoLivro;
        private System.Windows.Forms.Button btnCadastraLivro;
    }
}